package com.example.colourwithap

import android.app.Activity
import android.os.Bundle
import com.adobe.marketing.mobile.*
import com.adobe.marketing.mobile.edge.consent.Consent
import com.adobe.marketing.mobile.edge.identity.Identity
import java.util.*

@Suppress("UNUSED_EXPRESSION")
class ActivitySuccess : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_success)
        MobileCore.setApplication(this.application)
        MobileCore.setLogLevel(LoggingMode.DEBUG)
        val extensions = Arrays.asList(
            Consent.EXTENSION,
            Assurance.EXTENSION,
            Identity.EXTENSION,
            Edge.EXTENSION,
            UserProfile.EXTENSION,
            Lifecycle.EXTENSION,
            Signal.EXTENSION
        )
        MobileCore.registerExtensions(
            extensions
        ) { MobileCore.configureWithAppID("757ce0c442a6/433132b9f695/launch-5656686f0a83-development") }
        val reviewXdmData: MutableMap<String, Any> = mutableMapOf()
        val appStateDetail: MutableMap<String, Any> = mutableMapOf()
        appStateDetail["screenName"] = "Success Screen"
        appStateDetail["screenValue"] = 1
        reviewXdmData["appStateDetails"] = appStateDetail
        val xdmData: MutableMap<String, Any> = mutableMapOf()
        xdmData["eventType"] = "web.webPageDetails.pageViews"
        val experienceEvent = ExperienceEvent.Builder().setXdmSchema(xdmData).build()
        Edge.sendEvent(experienceEvent, null)
    }
}