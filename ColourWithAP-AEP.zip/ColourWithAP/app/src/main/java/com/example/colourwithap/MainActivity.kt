package com.example.colourwithap

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.adobe.marketing.mobile.*
import com.adobe.marketing.mobile.edge.consent.Consent
import com.adobe.marketing.mobile.edge.identity.Identity
import java.util.*


@Suppress("UNUSED_EXPRESSION")
class MainActivity : AppCompatActivity() {

    var button: Button? = null
    var textView: TextView? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        button = findViewById<View>(R.id.button) as Button
        textView = findViewById<View>(R.id.mainText) as TextView
        button!!.setOnClickListener(object : View.OnClickListener {
            override fun onClick(v: View?) {
                openNewActivity()
            }
        })
    }
    fun openNewActivity() {
        val intent = Intent(this, NewActivity::class.java)
        startActivity(intent)
        MobileCore.setApplication(this.application)
        MobileCore.setLogLevel(LoggingMode.DEBUG)
        val extensions = Arrays.asList(
            Consent.EXTENSION,
            Assurance.EXTENSION,
            Identity.EXTENSION,
            Edge.EXTENSION,
            UserProfile.EXTENSION,
            Lifecycle.EXTENSION,
            Signal.EXTENSION
        )
        MobileCore.registerExtensions(
            extensions
        ) { MobileCore.configureWithAppID("757ce0c442a6/433132b9f695/launch-5656686f0a83-development") }
        val reviewXdmData: MutableMap<String, Any> = mutableMapOf()
        val appStateDetail: MutableMap<String, Any> = mutableMapOf()
        appStateDetail["screenName"] = "Home Screen"
        appStateDetail["screenValue"] = 1
        reviewXdmData["appStateDetails"] = appStateDetail
        val xdmData: MutableMap<String, Any> = mutableMapOf()
        xdmData["eventType"] = "web.webPageDetails.pageViews"
        val experienceEvent = ExperienceEvent.Builder().setXdmSchema(xdmData).build()
        Edge.sendEvent(experienceEvent, null)
    }


    fun loadPage(view: View) {
        val browser = WebView(this)
        browser.settings.javaScriptEnabled = true
        browser.loadUrl("https://www.asianpaints.com/about-us.html")
        setContentView(browser)
        val ws = browser.settings
        ws.javaScriptEnabled = true
        browser.addJavascriptInterface(object : Any() {
            @JavascriptInterface // For API 17+
            fun performClick(strl: String?) {
                Toast.makeText(this@MainActivity, strl, Toast.LENGTH_SHORT).show()
            }
        }, "ok")
    }
}