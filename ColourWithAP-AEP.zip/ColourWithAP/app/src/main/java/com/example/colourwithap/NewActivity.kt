package com.example.colourwithap

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import com.adobe.marketing.mobile.*
import com.adobe.marketing.mobile.edge.consent.Consent
import com.adobe.marketing.mobile.edge.identity.Identity
import java.util.*

class NewActivity : AppCompatActivity() {
    var bookAnAppointment: Button? = null
    var email: EditText? = null
    var mobile: EditText? = null
    var emailId: Editable? = null
    var mobileNumber: Editable? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_new)
        bookAnAppointment = findViewById<View>(R.id.idBtnRegister) as Button
        bookAnAppointment!!.setOnClickListener(object : View.OnClickListener {
            override fun onClick(v: View?) {
                email = findViewById<View>(R.id.idEdtUserEmail) as EditText
                emailId = email!!.text
                mobile = findViewById<View>(R.id.idEdtMobile) as EditText
                mobileNumber = mobile!!.text
                openActivitySuccess()
            }
        })
    }

    fun openActivitySuccess() {
        val intent = Intent(this, ActivitySuccess::class.java)
        startActivity(intent)
        MobileCore.setApplication(this.application)
        MobileCore.setLogLevel(LoggingMode.DEBUG)
        val extensions = Arrays.asList(
            Consent.EXTENSION,
            Assurance.EXTENSION,
            Identity.EXTENSION,
            Edge.EXTENSION,
            UserProfile.EXTENSION,
            Lifecycle.EXTENSION,
            Signal.EXTENSION
        )
        MobileCore.registerExtensions(
        extensions
        ) { MobileCore.configureWithAppID("757ce0c442a6/433132b9f695/launch-5656686f0a83-development") }

        val reviewXdmData: MutableMap<String, Any> = mutableMapOf()
        val identification: MutableMap<String, Any> = mutableMapOf()
        val appInteraction: MutableMap<String, Any> = mutableMapOf()
        val appStateDetail: MutableMap<String, Any> = mutableMapOf()
        val appAction: MutableMap<String, Any> = mutableMapOf()
        appAction["Value"] = 1
        appInteraction["appAction"] = appAction
        appInteraction["name"] = "Enquiry Form"
        appStateDetail["screenName"] = "Form Screen"
        appStateDetail["screenValue"] = 1
        val core: MutableMap<String, Any> = mutableMapOf()
        //core["ecid"] = "56615460377184349746523751099613058624"
        core["email"] = emailId.toString()
        core["phoneNumber"] = mobileNumber.toString()
        identification["core"] = core
        reviewXdmData["identification"] = identification
        reviewXdmData["appInteraction"] = appInteraction
        reviewXdmData["appStateDetails"] = appStateDetail
        val xdmData: MutableMap<String, Any> = mutableMapOf()
        //xdmData["eventType"] = "web.webPageDetails.pageViews"
        xdmData["_wrkshp5snbxamer"] = reviewXdmData

        val experienceEvent = ExperienceEvent.Builder().setXdmSchema(xdmData).build()
        Edge.sendEvent(experienceEvent, null)

    }
}
